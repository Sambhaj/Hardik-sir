<?php
global $complete;
?>
<div class="fixed_site layer_wrapper">
  <div class="fixed_wrap fixindex">
	<?php if($complete['hide_boxes_section1'] == ''){?>   
    <section class="home1_section_area <?php if($complete['section1_bg_image']){ ?>home1_section_area_bg<?php } ?>" <?php if(!empty($complete['section1_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec1bgvideo = $complete['section1_bg_video']; echo do_shortcode($sec1bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section1_content">
             	  <?php
				  	$pagesetting1 = get_theme_mod( 'page-setting1');
					if ($pagesetting1 == '0'){
						echo do_shortcode('
[promobox2 bgcolor="#047cab" leftbordercolor="#047cab" color="#ffffff" button="BUY THEME" url="#" title="WASTE NO MORE TIME"]Buy the latest finance wordpress theme and be grow with us[/promobox2]
[space height="80"]
[service pattern="boxpattern-1" image="'.get_template_directory_uri().'/images/services-1.png" title="Financial Planning" readmore="" url="#"]Quisque pellentesque neque vitae metus convallis, et faucibus diam hendrerit.[/service]
[service pattern="boxpattern-1" image="'.get_template_directory_uri().'/images/services-2.png" title="Risk Management" readmore="" url="#"]Quisque pellentesque neque vitae metus convallis, et faucibus diam hendrerit.[/service]
[service pattern="boxpattern-1" image="'.get_template_directory_uri().'/images/services-3.png" title="fixed deposit" readmore="" url="#"]Quisque pellentesque neque vitae metus convallis, et faucibus diam hendrerit.[/service]
[service pattern="boxpattern-1" image="'.get_template_directory_uri().'/images/services-4.png" title="Support Team" readmore="" url="#"]Quisque pellentesque neque vitae metus convallis, et faucibus diam hendrerit.[/service]  
						');	
					}
					else
					{
					$secone = new WP_Query('page_id='.$pagesetting1.'');
					while ($secone->have_posts()) : $secone->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

    <?php if($complete['hide_boxes_section2'] ==''){?>
    <section class="home2_section_area <?php if($complete['section2_bg_image']){ ?>home2_section_area_bg<?php } ?>" <?php if(!empty($complete['section2_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec2bgvideo = $complete['section2_bg_video']; echo do_shortcode($sec2bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section2_content">
                    <?php
				  	$pagesetting2 = get_theme_mod( 'page-setting2');
					if ($pagesetting2 == '0'){
						echo do_shortcode('
						
[row_area]
[columns size="5"]&nbsp;[/columns]
[columns size="6"]
[titlearea align="left" title="What We Offer" titlelast="" subtitle="" titlecolor="#474747" titlelastcolor="#4c4c4c" seperatorcolor=""]
[space height="10"]
<p>Praesent nec enim vitae nibh ullamcorper consequat cursus ac dolor. Duis faucibus tortor magna sagittis tincidunt. Maecenas tincidunt viverra nipulvinar. Nam sed nibhe ligula viverra consectetur quis velit. Donec porttitor in diam id rutrum.</p>
[space height="30"]
[whatweoffer icon="'.get_template_directory_uri().'/images/what-we-do1.png" title="Financial Planning" description="Quisque pellentesque neque  faucibus diam hendrerit sede dictum est pretium." url="#" color="#969696" bgcolor="#ffffff"]
[whatweoffer icon="'.get_template_directory_uri().'/images/what-we-do2.png" title="Saving & Investments" description="Quisque pellentesque neque  faucibus diam hendrerit sede dictum est pretium." url="#" color="#969696" bgcolor="#ffffff" class="last"]
[whatweoffer icon="'.get_template_directory_uri().'/images/what-we-do3.png" title="Private Banking" description="Quisque pellentesque neque  faucibus diam hendrerit sede dictum est pretium." url="#" color="#969696" bgcolor="#ffffff"]
[whatweoffer icon="'.get_template_directory_uri().'/images/what-we-do3.png" title="Secured Transaction" description="Quisque pellentesque neque  faucibus diam hendrerit sede dictum est pretium." url="#" color="#969696" bgcolor="#ffffff" class="last"]
[/columns]
[clear]
[/row_area]
						');	
					}
					else
					{
					$sectwo = new WP_Query('page_id='.$pagesetting2.'');
					while ($sectwo->have_posts()) : $sectwo->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

     <?php if($complete['hide_boxes_section3'] ==''){?>
    <section id="demos" class="home3_section_area <?php if($complete['section3_bg_image']){ ?>home3_section_area_bg<?php } ?>" <?php if(!empty($complete['section3_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec3bgvideo = $complete['section3_bg_video']; echo do_shortcode($sec3bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section3_content">
                    <?php
				  	$pagesetting3 = get_theme_mod( 'page-setting3');
					if ($pagesetting3 == '0'){
						echo do_shortcode('
[tabs]
[tab title="Financial Planning"]<p>Praesent nec enim vitae nibh ullamcorper consequat cursus  dolor. Duis faucibus tortor in magna sagittis tincidunt. Maecenas tincidunt viverra nibh vel pulvinar. Nam sed nibh eu ligula viverra consectetur quis a velit. Donec porttitor in diam rutrum. Curabitur erat justo, tempus vitae nisl vitae, euismod accumsan libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p><p>Nulla eget vestibulum nisl, sit amet feugiat nisi. Nunc diam ipsum, congue non rhoncu finibus ut lorem. Vestibulum congue felis quis ligula egestas, a fermentum diam iaculis. Morbi lectus erat, sodales ac interdum non convallis ac elit. Donec tortor ipsum, consectetur vitae lectus sed, congue dictum ex. Aliquam pretium augue mi, sed euismody neque dignissim a. In efficitur vel velit non imperdiet. Suspendisse potenti. Suspendisse non leo porta, consectetur urna id, tincidunt massa. Aliquam consequat tempus dui, nec porta </p>[/tab]
[tab title="TAX Solution"]<p>Nulla eget vestibulum nisl, sit amet feugiat nisi. Nunc diam ipsum, congue non rhoncu finibus ut lorem. Vestibulum congue felis quis ligula egestas, a fermentum diam iaculis. Morbi lectus erat, sodales ac interdum non convallis ac elit. Donec tortor ipsum, consectetur vitae lectus sed, congue dictum ex. Aliquam pretium augue mi, sed euismody neque dignissim a. In efficitur vel velit non imperdiet. Suspendisse potenti. Suspendisse non leo porta, consectetur urna id, tincidunt massa. Aliquam consequat tempus dui, nec porta </p><p>Praesent nec enim vitae nibh ullamcorper consequat cursus  dolor. Duis faucibus tortor in magna sagittis tincidunt. Maecenas tincidunt viverra nibh vel pulvinar. Nam sed nibh eu ligula viverra consectetur quis a velit. Donec porttitor in diam rutrum. Curabitur erat justo, tempus vitae nisl vitae, euismod accumsan libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>[/tab]
[tab title="Market Research"]<p>Praesent nec enim vitae nibh ullamcorper consequat cursus  dolor. Duis faucibus tortor in magna sagittis tincidunt. Maecenas tincidunt viverra nibh vel pulvinar. Nam sed nibh eu ligula viverra consectetur quis a velit. Donec porttitor in diam rutrum. Curabitur erat justo, tempus vitae nisl vitae, euismod accumsan libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p><p>Nulla eget vestibulum nisl, sit amet feugiat nisi. Nunc diam ipsum, congue non rhoncu finibus ut lorem. Vestibulum congue felis quis ligula egestas, a fermentum diam iaculis. Morbi lectus erat, sodales ac interdum non convallis ac elit. Donec tortor ipsum, consectetur vitae lectus sed, congue dictum ex. Aliquam pretium augue mi, sed euismody neque dignissim a. In efficitur vel velit non imperdiet. Suspendisse potenti. Suspendisse non leo porta, consectetur urna id, tincidunt massa. Aliquam consequat tempus dui, nec porta </p>[/tab]
[tab title="Mutual Funds"]<p>Nulla eget vestibulum nisl, sit amet feugiat nisi. Nunc diam ipsum, congue non rhoncu finibus ut lorem. Vestibulum congue felis quis ligula egestas, a fermentum diam iaculis. Morbi lectus erat, sodales ac interdum non convallis ac elit. Donec tortor ipsum, consectetur vitae lectus sed, congue dictum ex. Aliquam pretium augue mi, sed euismody neque dignissim a. In efficitur vel velit non imperdiet. Suspendisse potenti. Suspendisse non leo porta, consectetur urna id, tincidunt massa. Aliquam consequat tempus dui, nec porta </p><p>Praesent nec enim vitae nibh ullamcorper consequat cursus  dolor. Duis faucibus tortor in magna sagittis tincidunt. Maecenas tincidunt viverra nibh vel pulvinar. Nam sed nibh eu ligula viverra consectetur quis a velit. Donec porttitor in diam rutrum. Curabitur erat justo, tempus vitae nisl vitae, euismod accumsan libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>[/tab]	 
[tab title="Mutual Funds"]<p>Praesent nec enim vitae nibh ullamcorper consequat cursus  dolor. Duis faucibus tortor in magna sagittis tincidunt. Maecenas tincidunt viverra nibh vel pulvinar. Nam sed nibh eu ligula viverra consectetur quis a velit. Donec porttitor in diam rutrum. Curabitur erat justo, tempus vitae nisl vitae, euismod accumsan libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p><p>Nulla eget vestibulum nisl, sit amet feugiat nisi. Nunc diam ipsum, congue non rhoncu finibus ut lorem. Vestibulum congue felis quis ligula egestas, a fermentum diam iaculis. Morbi lectus erat, sodales ac interdum non convallis ac elit. Donec tortor ipsum, consectetur vitae lectus sed, congue dictum ex. Aliquam pretium augue mi, sed euismody neque dignissim a. In efficitur vel velit non imperdiet. Suspendisse potenti. Suspendisse non leo porta, consectetur urna id, tincidunt massa. Aliquam consequat tempus dui, nec porta </p>[/tab]	
[/tabs] 

 

');	
					}
					else
					{
					$secthree = new WP_Query('page_id='.$pagesetting3.'');
					while ($secthree->have_posts()) : $secthree->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

     <?php if($complete['hide_boxes_section4'] ==''){?>
    <section class="home4_section_area <?php if($complete['section4_bg_image']){ ?>home4_section_area_bg<?php } ?>" <?php if(!empty($complete['section4_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec4bgvideo = $complete['section4_bg_video']; echo do_shortcode($sec4bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section4_content">
                    <?php
				  	$pagesetting4 = get_theme_mod( 'page-setting4');
					if ($pagesetting4 == '0'){
						echo do_shortcode('
						
[titlearea align="center" title="Latest News" titlelast="" subtitle="" titlecolor="#474747" titlelastcolor="" seperatorcolor="transparent"]
[posts-style4 show="3" cat="" excerptlength="28"]
');
					}
					else
					{
					$secfour = new WP_Query('page_id='.$pagesetting4.'');
					while ($secfour->have_posts()) : $secfour->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>              
            </div>
        </div>
    </section>
    <?php } ?>

     <?php if($complete['hide_boxes_section5'] ==''){?>
    <section class="home5_section_area <?php if($complete['section5_bg_image']){ ?>home5_section_area_bg<?php } ?>" <?php if(!empty($complete['section5_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec5bgvideo = $complete['section5_bg_video']; echo do_shortcode($sec5bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section5_content">
                    <?php
				  	$pagesetting5 = get_theme_mod( 'page-setting5');
					if ($pagesetting5 == '0'){
						echo do_shortcode('
[titlearea align="center" title="Facts of Finance" titlelast="" subtitle="" titlecolor="#ffffff" titlelastcolor="" seperatorcolor="transparent"]
[row_area] 
	[counter title="Complete Cases" count="500" color="#ffffff" bdcolor="#ffffff"]
	[counter title="Clients" count="200" color="#ffffff" bdcolor="#ffffff"]
	[counter title="Expert Advisors" count="40" color="#ffffff" bdcolor="#ffffff"]
	[counter title="Awards Won" count="100" color="#ffffff" bdcolor="#ffffff"]
	[counter title="Satisfied Customers" count="3000" color="#ffffff" bdcolor="#ffffff"]
[/row_area]
						');
					}
					else
					{
					$secfive = new WP_Query('page_id='.$pagesetting5.'');
					while ($secfive->have_posts()) : $secfive->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>            
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

     <?php if($complete['hide_boxes_section6'] ==''){?>
    <section class="home6_section_area <?php if($complete['section6_bg_image']){ ?>home6_section_area_bg<?php } ?>" <?php if(!empty($complete['section6_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec6bgvideo = $complete['section6_bg_video']; echo do_shortcode($sec6bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section6_content">
                    <?php
				  	$pagesetting6 = get_theme_mod( 'page-setting6');
					if ($pagesetting6 == '0'){
						echo do_shortcode('
[titlearea align="center" title="Our Expert Advisors" titlelast="" subtitle="" titlecolor="#474747" titlelastcolor="" seperatorcolor="transparent"]
[ourteam col="4" show="4" excerptlength=""]
						');
					}
					else
					{
					$secsix = new WP_Query('page_id='.$pagesetting6.'');
					while ($secsix->have_posts()) : $secsix->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>               
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

    <?php if($complete['hide_boxes_section7'] ==''){?>
    <section class="home7_section_area <?php if($complete['section7_bg_image']){ ?>home7_section_area_bg<?php } ?>" <?php if(!empty($complete['section7_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec7bgvideo = $complete['section7_bg_video']; echo do_shortcode($sec7bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section7_content">
                    <?php
				  	$pagesetting7 = get_theme_mod( 'page-setting7');
					if ($pagesetting7 == '0'){
						echo do_shortcode('
						
[titlearea align="center" title="Our Cases" titlelast="" subtitle=""titlecolor="#474747" titlelastcolor="" seperatorcolor="transparent"]
[ourcases icon="'.get_template_directory_uri().'/images/ourcases1.jpg" title="Startup Funding" description="Curabitur congue hendrerit sapieninterdum nunc rutrum no. Nullam pulvinar augue sed scelerisque luctus, augue velit porta leo, id sodales nisi enim eget risus." url="#" readmore="READ MORE" color="#777778"]
[ourcases icon="'.get_template_directory_uri().'/images/ourcases2.jpg" title="Family Asset Management" description="Curabitur congue hendrerit sapieninterdum nunc rutrum no. Nullam pulvinar augue sed scelerisque luctus, augue velit porta leo, id sodales nisi enim eget risus." url="#" readmore="READ MORE" color="#777778"]
[ourcases icon="'.get_template_directory_uri().'/images/ourcases3.jpg" title="Accounting Advisory" description="Curabitur congue hendrerit sapieninterdum nunc rutrum no. Nullam pulvinar augue sed scelerisque luctus, augue velit porta leo, id sodales nisi enim eget risus." url="#" readmore="READ MORE" color="#777778"]
[ourcases icon="'.get_template_directory_uri().'/images/ourcases4.jpg" title="Merger & Acquisition" description="Curabitur congue hendrerit sapieninterdum nunc rutrum no. Nullam pulvinar augue sed scelerisque luctus, augue velit porta leo, id sodales nisi enim eget risus." url="#" readmore="READ MORE" color="#777778"]
[clear]
[readmore align="center" icon="" button="VIEW ALL CASES" links="#" margintop="4%" target="_parent" color="#ffffff" bgcolor="#ffad00"] 
			');
					}
					else
					{
					$secseven = new WP_Query('page_id='.$pagesetting7.'');
					while ($secseven->have_posts()) : $secseven->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>                           
            </div>
        </div>
    </section>
    <?php wp_reset_postdata(); ?>
    <?php } ?>

     <?php if($complete['hide_boxes_section8'] ==''){?>
    <section class="home8_section_area <?php if($complete['section8_bg_image']){ ?>home8_section_area_bg<?php } ?>" <?php if(!empty($complete['section8_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec8bgvideo = $complete['section8_bg_video']; echo do_shortcode($sec8bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section8_content">
                    <?php
				  	$pagesetting8 = get_theme_mod( 'page-setting8');
					if ($pagesetting8 == '0'){
						echo do_shortcode('
						
						
[titlearea align="center" title="What Our Customers Say" titlelast="" subtitle="" titlecolor="#ffffff" titlelastcolor="" seperatorcolor=""]
[space height="20"]
[testimonials-rotator show="5"]						
						');	
					}
					else
					{
					$seceight = new WP_Query('page_id='.$pagesetting8.'');
					while ($seceight->have_posts()) : $seceight->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>            
            </div>
        </div>
    </section>
    <?php wp_reset_postdata(); ?>
    <?php } ?>

     <?php if($complete['hide_boxes_section9'] ==''){?>
    <section class="home9_section_area <?php if($complete['section9_bg_image']){ ?>home9_section_area_bg<?php } ?>" <?php if(!empty($complete['section9_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec9bgvideo = $complete['section9_bg_video']; echo do_shortcode($sec9bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section9_content">
                    <?php
				  	$pagesetting9 = get_theme_mod( 'page-setting9');
					if ($pagesetting9 == '0' ){
						echo ''.do_shortcode('
[row_area]
[columns size="2"]
[titlearea align="left" title="Request a call back?" titlelast="" subtitle="" titlecolor="#474747" titlelastcolor="" seperatorcolor="#1cb9c8"]
<p>Duis consequat semper feugiat. Quisque ut arcu risus. Vestibulum eleifend, nibh non vestibulum consequat, leo elit consequat dolor, in pharetra lorem tortor sed libero. Suspendisse finibus faucibus nisl ac congue.</p>
<p>Aliquam erat volutpat. Cras varius finibus faucibus. Ut at libero et est suscipit placerat. Curabitur congue hendrerit sapien, sed interdum nunc rutrum non. Nullam pulvinar, augue sed scelerisque luctus, augue velit porta leo, id sodales nisi enim eget risus. Sed eget velit dapibus, fringilla arcu feugiat, pretium eros. Aliquam blandit, orci a mollis vestibulum, est elit cursus enim, a imperdiet nulla magna sit amet urna. Nullam commodo, mauris in faucibus posuere, ipsum augue vestibulum leo, id aliquam mauris nulla eget leo. </p>
[/columns]
[columns size="2"]
[contact-form-7 id="4623" title="Request a call back?"]
[/columns]
[clear]
[/row_area]
						
						');
					}
					else
					{
					$secnine = new WP_Query('page_id='.$pagesetting9.'');
					while ($secnine->have_posts()) : $secnine->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

     <?php if($complete['hide_boxes_section10'] == '' ){?>
    <section class="home10_section_area <?php if($complete['section10_bg_image']){ ?>home10_section_area_bg<?php } ?>" <?php if(!empty($complete['section10_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec10bgvideo = $complete['section10_bg_video']; echo do_shortcode($sec10bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section10_content">
                    <?php
				  	$pagesetting10 = get_theme_mod( 'page-setting10');
					if ($pagesetting10 == '0'){
						echo do_shortcode('
[client_slider]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo1.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo2.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo3.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo4.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo5.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo6.jpg"]
	[client url="#" image="'.get_template_directory_uri().'/images/client-logo4.jpg"]
[/client_slider]
');	
					}
					else
					{
					$secten = new WP_Query('page_id='.$pagesetting10.'');
					while ($secten->have_posts()) : $secten->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

     <?php if($complete['hide_boxes_section11'] ==''){?>
    <section class="home11_section_area <?php if($complete['section11_bg_image']){ ?>home11_section_area_bg<?php } ?>" <?php if(!empty($complete['section11_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec11bgvideo = $complete['section11_bg_video']; echo do_shortcode($sec11bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section11_content">
                    <?php
				  	$pagesetting11 = get_theme_mod( 'page-setting11');
					if ($pagesetting11 == '0' ){
						echo do_shortcode('[titlearea align="center" title="Pricing Table" titlelast="" subtitle="" titlecolor="#ffffff" titlelastcolor="" seperatorcolor=""]
[plans columns="3" haspopular="yes"][plan title="BASIC" price="$59" pricedes="Per month" btntext="PURCHASE" btnlink="#"]<li class="yes">90 Keyword</li><li class="no" >No Time Tracking</li><li class="yes">300 - Man Hour</li><li class="no">News Letter Available</li>[/plan][plan popular="yes" title="STANDERD" price="$75" pricedes="Per month" btntext="PURCHASE" btnlink="#"]<li class="yes">90 Keyword</li><li class="yes" >No Time Tracking</li><li class="yes">300 - Man Hour</li><li class="yes">News Letter Available</li>[/plan][plan title="ULTIMATE" price="$99" pricedes="Per month" btntext="PURCHASE" btnlink="#"]<li class="yes">90 Keyword</li><li class="yes" >No Time Tracking</li><li class="yes">300 - Man Hour</li><li class="yes">News Letter Available</li>[/plan][/plans][space height="30"]	');	
					}
					else
					{
					$seceleven = new WP_Query('page_id='.$pagesetting11.'');
					while ($seceleven->have_posts()) : $seceleven->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section12'] ==''){?>
    <section class="home12_section_area <?php if($complete['section12_bg_image']){ ?>home12_section_area_bg<?php } ?>" <?php if(!empty($complete['section12_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec12bgvideo = $complete['section12_bg_video']; echo do_shortcode($sec12bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section12_content">
                <?php
                $pagesetting12 = get_theme_mod( 'page-setting12');
                if ($pagesetting12 == '0' ){
                    echo 'Coming Soon...';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting12.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section13'] ==''){?>
    <section class="home13_section_area <?php if($complete['section13_bg_image']){ ?>home13_section_area_bg<?php } ?>" <?php if(!empty($complete['section13_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec13bgvideo = $complete['section13_bg_video']; echo do_shortcode($sec13bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section13_content">
                <?php
                $pagesetting13 = get_theme_mod( 'page-setting13');
                if ($pagesetting13 == '0' ){
                    echo 'Coming Soon...';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting13.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section14'] ==''){?>
    <section class="home14_section_area <?php if($complete['section14_bg_image']){ ?>home14_section_area_bg<?php } ?>" <?php if(!empty($complete['section14_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec14bgvideo = $complete['section14_bg_video']; echo do_shortcode($sec14bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section14_content">
                <?php
                $pagesetting14 = get_theme_mod( 'page-setting14');
                if ($pagesetting14 == '0' ){
                    echo 'Coming Soon...';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting14.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section15'] ==''){?>
    <section class="home15_section_area <?php if($complete['section15_bg_image']){ ?>home15_section_area_bg<?php } ?>" <?php if(!empty($complete['section15_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec15bgvideo = $complete['section15_bg_video']; echo do_shortcode($sec15bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section15_content">
                <?php
                $pagesetting15 = get_theme_mod( 'page-setting15');
                if ($pagesetting15 == '0' ){
                    echo 'Coming Soon...';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting15.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section16'] ==''){?>
    <section class="home16_section_area <?php if($complete['section16_bg_image']){ ?>home16_section_area_bg<?php } ?>" <?php if(!empty($complete['section16_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec16bgvideo = $complete['section16_bg_video']; echo do_shortcode($sec16bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section16_content">
                <?php
                $pagesetting16 = get_theme_mod( 'page-setting16');
                if ($pagesetting16 == '0' ){
                    echo 'Coming Soon...';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting16.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>

	<?php if($complete['hide_boxes_section17'] ==''){?>
    <section class="home17_section_area <?php if($complete['section17_bg_image']){ ?>home17_section_area_bg<?php } ?>" <?php if(!empty($complete['section17_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec17bgvideo = $complete['section17_bg_video']; echo do_shortcode($sec17bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section17_content">
                <?php
                $pagesetting17 = get_theme_mod( 'page-setting17');
                if ($pagesetting17 == '0' ){
                    echo 'Section 17 Content';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting17.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
  </div>
</div>