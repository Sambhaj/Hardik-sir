<?php
function complete_option_defaults() {
	$defaults = array(
		'converted' => '',
		'site_layout_id' => 'site_full',
		'single_post_layout_id' => 'single_layout1',
		'header_layout_id' => 'header_layout2',
		'center_width' => 83.50,
		'content_bg_color' => '#ffffff',
		'divider_icon' => 'fa-stop',
		'head_transparent' => '',
		'trans_header_color' => '#ffffff',
		'totop_id' => '1',
		'footer_text_id' => __('&copy; Copyright 2018 <a href="#">Finance Co.</a>. All Rights Reserved by <a href="https://www.sktthemes.net/" target="_blank" rel="nofollow">SKT Themes</a> ', 'complete'),
		
		
		'phntp_text_id' => __('<i class="fa fa-map-marker"></i> 15, Edison Street, Thomson Avenue,<br />Baltimore, USA', 'complete'),
		'emltp_text' => __('<i class="fa fa-comments-o"></i> info@companysite.com <br />we reply in 24 hours', 'complete'),
		'sintp_text' => __('<i class="fa fa-phone"></i>337-413-9538 <br />mon-fri , 08.am - 17.pm', 'complete'),
		'suptp_text' => __('Donec ultricies mattis nulla', 'complete'),
		
		
		'footmenu_id' => '1',
		'copyright_center' => '',
		
		'custom_slider' => '',
		
		'slider_type_id' => 'static',
		
		'slideefect' => 'fade',
		'slideanim' => '500',
		'slidepause' => '4000',
		'slidenav' => 'false',
		'slidepage' => 'false',
		
		'n_slide_time_id' => '6000',
		'slide_height' => '500px',
		'slidefont_size_id' => '36px',
		'slider_txt_hide' => '',

		'post_info_id' => '1',
		'post_nextprev_id' => '1',
		'post_comments_id' => '1',
		'page_header_color' => '#545556',
		'pageheader_bg_image' => '',
		'hide_pageheader' => '',
		'page_header_txtcolor' => '#555555',
		
		'post_header_color' => '#545556',
		'postheader_bg_image' => '',
		'hide_postheader' => '',		

		'blog_cat_id' => '',
		'blog_num_id' => '9',
		'blog_layout_id' => '',
		'show_blog_thumb' => '1',
		
		'sec_color_id' => '#1cb9c8',
		'mnbg_color_id' => '#047fad',
		'submnu_textcolor_id' => '#282828',
		'submnbg_color_id' => '#e8f1f6',
		'mnshvr_color_id' => '#047fad',
		'mobbg_color_id' => '#383939',
		'mobbgtop_color_id' => '#047fad',
		'mobmenutxt_color_id' => '#FFFFFF',
		
		'mobtoggle_color_id' => '#000000',
		'mobtoggleinner_color_id' => '#FFFFFF',
		
		'sectxt_color_id' => '#FFFFFF',
		'content_font_id' =>  array('font-family' => 'Roboto', 'font-size' => '15px'),
		'primtxt_color_id' => '#606060',
		'logo_image_id' => array(  'url'=> get_template_directory_uri().'/images/logo.png' ),
		'logo_font_id' => array('font-family' => 'Roboto Condensed', 'font-size' => '36px'),
		'logo_color_id' => '#4f4f4f',
		'logolast_color_id' => '#4f4f4f',
		
		
		'logo_image_height' => '29px;',
		'logo_image_width' => '184px;',
		'logo_margin_top' => '30px;',
		
		'tpbt_font_id' => array('font-family' => 'Roboto', 'font-size' => '13px'),
		'tpbt_color_id' => '#5c5c5d',
		'tpbt_hvcolor_id' => '#047fad',	
		
		'sldtitle_font_id' => array('font-family' => 'Roboto', 'font-size' => '76px'),
		'slddesc_font_id' => array('font-family' => 'Roboto', 'font-size' => '17px'),
		'sldbtn_font_id' => array('font-family' => 'Roboto', 'font-size' => '14px'),
		
		'slidetitle_color_id' => '#ffffff',	
		'slddesc_color_id' => '#ffffff',	
		'sldbtntext_color_id' => '#ffffff',
		'sldbtn_color_id' => '#ffad00',
		'sldbtn_hvcolor_id' => '#282828',	
		
		'slide_pager_color_id' => '#ffffff',	
		'slide_active_pager_color_id' => '#047fad',	
		
			
		'global_link_color_id' => '#047fad',
		'global_link_hvcolor_id' => '#282828',		
		
		'global_h1_color_id' => '#373737',
		'global_h1_hvcolor_id' => '#047fad',	
		'global_h2_color_id' => '#373737',
		'global_h2_hvcolor_id' => '#047fad',
		'global_h3_color_id' => '#373737',
		'global_h3_hvcolor_id' => '#047fad',
		'global_h4_color_id' => '#373737',
		'global_h4_hvcolor_id' => '#047fad',
		'global_h5_color_id' => '#464646',
		'global_h5_hvcolor_id' => '#047fad',
		'global_h6_color_id' => '#373737',
		'global_h6_hvcolor_id' => '#047fad',	
 
 		'carousel_bg_color_id' => '#393939',
		'carousel_bg_hover_color' => '#047fad',
		
		'post_meta_color_id' => '#282828',
		
		'team_box_color_id' => '#fafafa',
		'team_box_hover_color_id' => '#047fad',
		'team_box_hover_color' => '#ffffff',
		
		'social_text_color_id' => '#ffffff',
		'social_hover_text_color_id' => '#047fad',
		'social_icon_color_id' => '#1c1c1c',
		'social_hover_icon_color_id' => '#ffffff',
		'testimonialbox_color_id' => '#037FAC',		
		'testimonialbox_txt_color' => '#ffffff',
		'testimonial_pager_color_id' => '#ffffff',
		'testimonial_activepager_color_id' => '#ffad00',
		
		'gallery_boxbg_color_id' => '#047fad',		
		'gallery_title_color_id' => '#ffffff',		
		'gallery_filter_color_id' => '#047fad',
		'gallery_filtertxt_color_id' => '#000000',
		'gallery_activefiltertxt_color_id' => '#ffffff',
		
		'skillsbar_bgcolor_id' => '#f8f8f8',
		'skillsbar_text_color_id' => '#ffffff',								
		'global_h1_font_id' => array('font-family' => 'Roboto Condensed', 'font-size' => '32px'),
		'global_h2_font_id' => array('font-family' => 'Roboto', 'font-size' => '34px'),
		'global_h3_font_id' => array('font-family' => 'Roboto', 'font-size' => '24px'),
		'global_h4_font_id' => array('font-family' => 'Roboto', 'font-size' => '21px'),
		'global_h5_font_id' => array('font-family' => 'Roboto', 'font-size' => '20px'),
		'global_h6_font_id' => array('font-family' => 'Roboto', 'font-size' => '18px'),
		
		'contact_title' => 'Contact Info',
		'contact_address' => 'Donec ultricies mattis nulla Australia',
		'contact_phone' => '0789 256 321',
		'contact_email' => 'info@companyname.com',
		'contact_company_url' => 'http://demo.com',
		
		'head_bg_trans' => '1',
		'head_color_id' => '#ffffff',
		'head_info_color_id' => '#f9f9f9',
		
		'head_info_opacity_id' => '1',
		
		'header_border_color' => '#dddddd',
		
		'menu_bg_color_id' => '#000000',
		'menu_bg_opacity_id' => '0.2',
		
		'menutxt_color_id' => '#ffffff',  
		'menutxt_color_hover' => '#ffffff',
		'menutxt_color_active' => '#ffffff',
		'menu_size_id' => '16px',
		'sidebar_color_id' => '#FFFFFF',
		'sidebarborder_color_id' => '#eeeff5',
		'sidebar_tt_color_id' => '#666666',
		'sidebartxt_color_id' => '#999999',
		'sidebarlink_color_id' => '#141414',
		'sidebarlink_hover_color_id' => '#047fad',
		'flipbg_front_color_id' => '#ffffff',
		'flipbg_back_color_id' => '#f7f7f7',
		'flipborder_front_color_id' => '#e0e0e0',
		'flipborder_back_color_id' => '#000000',
		'divider_color_id' => '#8c8b8b',
		'wgttitle_size_id' => '20px',
		'timebox_color_id' => '#ffffff',
		'timeboxborder_color_id' => '#dedede',
		'gridbox_color_id' => '#ffffff',
		'gridboxborder_color_id' => '#cccccc',
		
		'service_box_bg' => '',
		'service_box_bg_hover' => '',
		'box_color_text' => '#464646',
		'box_color_hover_text' => '#047fad',
		'service_image_bg' => '#f9f8f8',
		
		'tab_bgbd_color' => '#ffffff',
		'tab_color_id' => '#ffffff',
		'tab_active_color' => '#036a9f',
		
		'expand_bg_color' => '#047fad',
		'expand_text_color' => '#000000',
		
		'h_seprator_color' => '#047fad',
		'h_seprator_text_color' => '#000000',
		
		'table_bg_color' => '#ffffff',
		'tableprice_bg_color' => '#047fad',
		'tableprice_text_color' => '#ffffff',
		'plantable_text_color' => '#454646',
		'planbutton_bg_color' => '#fafafa',
		
		
		
		'square_bg_color' => '#ffffff',
		'square_bg_hover_color' => '#79ab9f',
		'square_title_color' => '#000000',
		
		'style3_bg_color' => '#ffffff',
		'style3_hover_bg_color' => '#f3f3f3',
		'style3_border_color' => '#f3f3f3',
		
		'style4_bg_color' => '',
		'poststyle4_hover_color' => '#047fad',
		
		'perfect_bg_color' => '#ffffff',
		'perfect_border_color' => '#eaeaea',
		'perfect_hover_border_color' => '#047fad',
 
		'foot_layout_id' => '4',
		'footer_color_id' => '#212121',
		'footer_bg_image' => '',
		
		'footwdgtxt_color_id' => '#d9d9d9',
		'footwdgtxtactive_color_id' => '#1cb9c8',
		'footer_title_color' => '#ffffff',
		'ptitle_font_id' =>  array('font-family' => 'Lato', 'subsets'=>'latin'),
		'mnutitle_font_id' =>  array('font-family' => 'Roboto', 'subsets'=>'latin'),
		'title_txt_color_id' => '#282828',
		'link_color_id' => '#3590ea',
		'link_color_hover' => '#1e73be',
		'txt_upcase_id' => '',
		'mnutxt_upcase_id' => '0',
		'copyright_bg_color' => '#191919',
		'copyright_txt_color' => '#8d8e8e',
		
		//Footer Info Box
		'footer_info_bgcolor' => '#161616',
		'footer_info_iconcolor' => '#ffffff',
		'footer_info_titlecolor' => '#ffffff',
		'footer_info_desccolor' => '#757575',
		'footer_info_shrtcolor' => '#047fad',
		'footer_info_dividercolor' => '#1f1f1f',		
		
		//Featured Box
		'featured_section_title' => __('Featured Boxes', 'complete'),
		'homeblock_bg_setting' => '',
		'ftd_bg_video' => '',
		'homeblock_title_color' => '#000000',
		'homeblock_color_id' => '#f2f2f2',
		'featured_image_height' => '70px;',
		'featured_image_width' => '70px;',
		'featured_excerpt' => '35',
		'featured_block_bg' => '#ffffff',
//		'featured_block_button' => __('READ MORE', 'complete'),
		'recentpost_block_button' => __('Read More', 'complete'),
		
		'featured_block_button_bg' => '#383939',
		'featured_block_hover_button_bg' => '#047fad',
		
		'page-setting1_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon1.png'),
		'page-setting2_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon2.png'),
		'page-setting3_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon3.png'),
		'page-setting4_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon4.png'),
		
		'page-setting1' => '0',
		'page-setting2' => '0',
		'page-setting3' => '0',
		'page-setting4' => '0',
		'page-setting5' => '0',
		'page-setting6' => '0',
		'page-setting7' => '0',
		'page-setting8' => '0',
		'page-setting9' => '0',
		'page-setting10' => '0',
		'page-setting11' => '0',
		'page-setting12' => '0',
		'page-setting13' => '0',
		'page-setting14' => '0',
		'page-setting15' => '0',
		'page-setting16' => '0',
		'page-setting17' => '0',
		'hide_boxes' => '',
		
		//Home Section1
		'section1_bgcolor_id' => '#ffffff',
		'section1_bg_image' => '',
		'section1_bg_video' => '',
		'hide_boxes_section1' => '',
		//Home Section1
		
		//Home Section2
		'section2_bgcolor_id' => '#f1f1f1',
		'section2_bg_image' => ''.get_template_directory_uri().'/images/section-2-bg.jpg',
		'section2_bg_video' => '',
		'hide_boxes_section2' => '',
		//Home Section2	
		
		//Home Section3
		'section3_bgcolor_id' => '#035c96',
		'section3_bg_image' => ''.get_template_directory_uri().'/images/section-3-bg.jpg',
		'section3_bg_video' => '',
		'hide_boxes_section3' => '',
		//Home Section3	
		
		//Home Section4
		'section4_bgcolor_id' => '#ffffff',
		'section4_bg_image' => '',
		'section4_bg_video' => '',
		'hide_boxes_section4' => '',
		//Home Section4		
		
		//Home Section5
		'section5_bgcolor_id' => '#fafafa',
		'section5_bg_image' => ''.get_template_directory_uri().'/images/section-5-bg.jpg',
		'section5_bg_video' => '',
		'hide_boxes_section5' => '',
		//Home Section5		
		
		//Home Section6
		'section6_bgcolor_id' => '#f1f1f1',
		'section6_bg_image' => '',
		'section5_bg_video' => '',
		'hide_boxes_section6' => '',
		//Home Section6	
		
		//Home Section7
		'section7_bgcolor_id' => '#ffffff',
		'section7_bg_image' => '',
		'section7_bg_video' => '',
		'hide_boxes_section7' => '',
		//Home Section7		
		
		//Home Section8
		'section8_bgcolor_id' => '#ffffff',
		'section8_bg_image' => ''.get_template_directory_uri().'/images/section-8-bg.jpg',
		'section8_bg_video' => '',
		'hide_boxes_section8' => '',
		//Home Section8		
		
		//Home Section9
		'section9_bgcolor_id' => '#ffffff',
		'section9_bg_image' => '',
		'section9_bg_video' => '',
		'hide_boxes_section9' => '',
		//Home Section9	
		
		//Home Section10
		'section10_bgcolor_id' => '#f1f1f1',
		'section10_bg_image' => '',
		'section10_bg_video' => '',
		'hide_boxes_section10' => '',
		//Home Section10
		
		//Home Section11
		'section11_bgcolor_id' => '#cacaca',
		'section11_bg_image' => '',
		'section11_bg_video' => '',
		'hide_boxes_section11' => '1',
		//Home Section11	
		
		//Home Section12
		'section12_bgcolor_id' => '#f1f1f1',
		'section12_bg_image' => '',
		'section12_bg_video' => '',
		'hide_boxes_section12' => '1',
		//Home Section12
		
		//Home Section13
		'section13_bgcolor_id' => '#ffffff',
		'section13_bg_image' => '',
		'section13_bg_video' => '',
		'hide_boxes_section13' => '1',
		//Home Section13
		
		//Home Section14
		'section14_bgcolor_id' => '#f1f1f1',
		'section14_bg_image' => '',
		'section14_bg_video' => '',
		'hide_boxes_section14' => '1',
		//Home Section14
		
		//Home Section15
		'section15_bgcolor_id' => '#f6f6f6',
		'section15_bg_image' => '',
		'section15_bg_video' => '',
		'hide_boxes_section15' => '1',
		//Home Section15
		
		//Home Section16
		'section16_bgcolor_id' => '#ffffff',
		'section16_bg_image' => '',
		'section16_bg_video' => '',
		'hide_boxes_section16' => '1',
		//Home Section16
		
		//Home Section17
		'section17_bgcolor_id' => '#ffffff',
		'section17_bg_image' => '',
		'section17_bg_video' => '',
		'hide_boxes_section17' => '1',
		//Home Section17												
		
		
		//Footer Column 1
		'foot_cols1_title' => __('ABOUT FINANCE CO.', 'complete'),
		'foot_cols1_content' => '
		<p>Street 238,52 tempor <br>Donec ultricies mattis nulla, suscipit <br>risus tristique ut.</p>
		[space height="20px"]
		<p><span>Phone:</span> 1.800.555.6789</p>
		<p><span>E-mail:</span> <a href="mailto:support@sitename.com">support@sitename.com</a></p> 
		<p><span>Website:</span> <a href="https://www.sktthemes.net">sktthemes.net</a></p>',
		//Footer Column 1	
		
		//Footer Column 2
		'foot_cols2_title' => __('RECENT BLOG', 'complete'),
		'foot_cols2_content' => '[footerposts show="7" ]',
		//Footer Column 2	
		
		//Footer Column 3
		'foot_cols3_title' => __('QUICK LINKS', 'complete'),
		'foot_cols3_content' => '[footermenu]',
		//Footer Column 3
		
		//Footer Column 4
		'foot_cols4_title' => __('NEWSLETTER', 'complete'),
		'foot_cols4_content' => '<form class="newsletter-form"><input placeholder="Enter your email" type="email"><i class="fa fa-paper-plane" aria-hidden="true"><input value="" type="submit"></i></form>
		[social_area]
			[social icon="facebook" link="#"]
			[social icon="twitter" link="#"]
			[social icon="google-plus" link="#"]
			[social icon="linkedin" link="#"]
			[social icon="pinterest" link="#"]
			[social icon="skype" link="#"]
		[/social_area]
',
		//Footer Column 4																
		'social_button_style' => 'simple',
		'social_show_color' => '',
		'social_bookmark_pos' => 'footer',
		'social_bookmark_size' => 'normal',
		'social_single_id' => '1',
		'social_page_id' => '',
		
		//Footer Info Box 1
		'foot_infobox1_heading' => __('VISIT US', 'complete'),
		'foot_infobox1_icon' => '<i class="fa fa-map-o" aria-hidden="true"></i>',
		'foot_infobox1_description' => 'Aliquam porta tincidunt enim.',
		
		//Footer Info Box 2
		'foot_infobox2_heading' => __('EMAIL US', 'complete'),
		'foot_infobox2_icon' => '<i class="fa fa-envelope-o" aria-hidden="true"></i>',
		'foot_infobox2_description' => 'info@sitename.com',
		
		//Footer Info Box 3
		'foot_infobox3_heading' => __('CALL US', 'complete'),
		'foot_infobox3_icon' => '<i class="fa fa-phone" aria-hidden="true"></i>',
		'foot_infobox3_description' => '987 685 4528',
		
		'hide_foot_infobox' => '1',
		
		'post_lightbox_id' => '1',
		'post_gallery_id' => '1',
		'cat_layout_id' => '4',
		'hide_mob_slide' => '',
		'hide_mob_rightsdbr' => '',
		'hide_mob_page_header' => '1',
		'custom-css' => '',
	);
	
      $options = get_option('complete',$defaults);

      //Parse defaults again - see comments
      $options = wp_parse_args( $options, $defaults );

	return $options;
}?>